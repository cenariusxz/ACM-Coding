# EXsimple
know about SimpleHTTPRequestHandler?still not simple enough?so here is EXsimple.

# what is it:
  an extention to the SimpleHTTPRequestHandler,includes:
  file upload
  folder download
  folder upload
  and a better html operator interface
  
# please:
  find this line in exsimple.py:  DEFAULT_SERVER_IP = '192.168.135.213';
  and change it to your own IP

# notice:
  some codes are not modified(or copied) by others in their teaching blogs.I had put links on the front these codes.of course I had no rights with these codes.thanks for the original authors to write blogs to teach me so much.thank you.
  if you are one of these authors,but you don't want me use your code ,please tell me.I will rewrite that part.
  
# how to use:

  simple: (in windows)
          double click.
          it will show start and show you what you wanna know.
          (in linux)
          cd to the folder witch exsimple.py in.
          python3 exsimple.py
          it will show start and show you what you wanna know.
  advanced:
          open the score code to change whatever you want.
